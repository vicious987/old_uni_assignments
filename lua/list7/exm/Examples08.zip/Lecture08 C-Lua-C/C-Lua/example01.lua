
mycolor = {red=0.30, green=0.10, blue=0}

definedcolor = GREEN

stringcolor = 'RED'
