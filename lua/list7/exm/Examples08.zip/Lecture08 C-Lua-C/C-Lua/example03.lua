
function f (x, y)
  return (x^2 * math.sin(y))/(1 - x)
end

function g ()
  --print "I'm here"
  return 'Hello World!'
end

function h (a, b)
  return b, a
end